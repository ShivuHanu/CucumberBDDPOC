package StepDefination;

import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.json.JSONException;
import org.json.JSONObject;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.skyscreamer.jsonassert.JSONAssert;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.test.web.server.LocalServerPort;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.in28minutes.springboot.studentservices.StudentServicesApplication;
import com.in28minutes.springboot.studentservices.model.Course;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

@ExtendWith(SpringExtension.class)
@SpringBootTest(classes = StudentServicesApplication.class, webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class StudentControllerIT {
    @LocalServerPort
    private int port;
    TestRestTemplate restTemplate = new TestRestTemplate();

    HttpHeaders headers = new HttpHeaders();
    ResponseEntity<String> response=null;
    HttpEntity<Course> entity=null;
   
    @When("Hit on Get Student Course Endpoint")
	public void hit_on_get_student_course_endpoint() throws IOException {

        HttpEntity<String> entity = new HttpEntity<>(null, headers);
        response = restTemplate.exchange(
		createURLWithPort("/students/Student1/courses/Course1"), HttpMethod.GET,
		entity, String.class);
		 
    }
      
    @Then("Verify Get student Course Response")
	public void verify_get_student_course_response() throws JSONException {
        String expected = "{\"id\":\"Course1\",\"name\":\"Spring\",\"description\":\"10 Steps\"}";
        String responseBody=response.getBody();
        String ResCode=response.getStatusCode().toString();
        if(ResCode.equals("200 OK"))
        {
        	 JSONAssert.assertEquals(expected, response.getBody(), false);
        }
        else
        {
        	throw new RuntimeException("Get Student course API failed");
        	
        }
       
    }

    @When("Configure Coruse details using DataTable")
    public void configure_coruse_details_using_data_table(DataTable dataTable) {
				/*
				 * Course course = new Course("Course1", "Spring", "10Steps",
				 * List.of("Learn Maven", "Import Project", "First Example", "Second Example"));
				 */
    	 List<List<String>> courseData=dataTable.cells();
    	 
    	 String strCourde=courseData.get(0).get(3);
    	 String[] arrCourse = strCourde.split(";");
    	 List<String> CourseList = new ArrayList<>();
    	 for (String strCourseName : CourseList) {
    		 CourseList.add(strCourseName);
    	 }
    	 
    	 Course course = new Course(courseData.get(0).get(0), courseData.get(0).get(1), courseData.get(0).get(2),CourseList);
		 entity = new HttpEntity<>(course, headers);
		 
	}
    
    @And("Hit on Post Add Course Endpoint")
	public void hit_on_post_add_course_endpoint() {
		response = restTemplate.exchange(
	    createURLWithPort("/students/Student1/courses"),
	    HttpMethod.POST, entity, String.class);
	}

	@Then("Verify Course Created for a Student")
	public void verify_course_created_for_a_student() {
		String actual = response.getHeaders().get(HttpHeaders.LOCATION).get(0);
		String actresponseCode = response.getStatusCode().toString();
		 if(actresponseCode.equals("201 CREATED"))
	     {
			 assertTrue(actual.contains("/students/Student1/courses/"));
	     }
		 else
		 {
			 throw new RuntimeException("Create Course Student API failed");	 
		 }
	}
       
    private String createURLWithPort(String uri) {
    	System.out.println("http://localhost:" + port + uri);
        return "http://localhost:" + port + uri;
    }
}
