package StepDefination;

import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;

import io.cucumber.junit.*;
import io.cucumber.junit.CucumberOptions;

@RunWith(Cucumber.class)
@CucumberOptions(features="src/test/resources/Feature",
glue= {"StepDefination"},
plugin = {"pretty",
		"html:target/MyReport/cucumber.html",
		"junit:target/MyReport/cucumber.xml"},
publish=true		
)
public class StepRunner {

}
